/*******************************************************************************
*
* Created by: Matthew Brean
* Created on: 2019-10-03
* Created for: ICS4U
* Daily Assignment: #2-03
* Making it crash proof
*
*******************************************************************************/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;


public class ComboLock {

	public static void main(String[] args) throws IOException {
			
	        MrCoxallClass aStack = new MrCoxallClass();
	        String anItem;
			
	        InputStreamReader r = new InputStreamReader(System.in);
	        BufferedReader br = new BufferedReader(r);
	        
	        System.out.println("String/Int for stack #1");
	        
	            anItem = br.readLine();
	            aStack.push(anItem);
	            
	        System.out.println("String/Int for stack #2");
	        anItem = br.readLine();
	        aStack.push(anItem);
	        
	        System.out.println("Popping last push...");
	            aStack.pop(anItem);

	    }
		
	}


